var searchData=
[
  ['duration',['duration',['../class_bounce.html#a62412d814d36102ab3d285e801d5d29a',1,'Bounce']]]
];
