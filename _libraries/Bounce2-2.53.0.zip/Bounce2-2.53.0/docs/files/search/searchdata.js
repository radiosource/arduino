var indexSectionsWithContent =
{
  0: "abdfiru",
  1: "b",
  2: "abdfiru",
  3: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Pages"
};

